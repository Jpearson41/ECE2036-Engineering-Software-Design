
#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>

using namespace std;

//In C/C++ use can use additional preprocessor directives
//which always start with a # to define constants.
//Later I will show you a C++ version that is better.

#define convertCubicFtToCubicMeter  0.02837262 //(2.54*12/100)^3

//Global Variable Declaration
//------------------------------------------

//This is not necessarily good programming practice,
//but I would like for you to understand 
//what a "global" variable is. Can you think
//why using a lot of global variables could
//cause problems?

float 	lengthOfRoomft= 0;
float   widthOfRoomft = 0;
float 	heightOfRoomft = 0; 
int 	durationOfEventInMins =0;
int 	numRepsOfEvent = 0;
float 	ventilationWithOutsideAir = 0;
float 	decayRateOfVirus = 0;
float	depositionToSurfaces =0;
float	additionalControlMeasures = 0;
int 	numPeoplePresent = 0;
float	numInfectedPeopleInRoom = 0;
float	fractionOfPopulationImmune = 0; 
float	breathingRateSusceptiblePeople =0;
float 	quantaExhalationRate_Infected = 0;
float	exhalationMaskEfficiency =0;
float 	fractionPeopleWearingMasks = 0;
float	inhalationMaskEfficiency =0;
float  	infectionRateInYourArea =0;


//Global Function Prototypes
//------------------------------------------

//You will need to provide the implementations after the 
//main function. For now, put all in one file.
void readInValues();
float volOfRoom();
void createDirectOutput();
float totalFirstOrderViralLossRate();
float numPeopleSusceptible();
float ventRatePerPerson();
float areaPerPersonInRoom();
float personsPerSquareMeter();
float volumePerPerson();
float netEmissionRateFromInfected();
float avgQuantaConcentration();
float quantaInhaledPerPerson();
float probabilityOfInfection_Conditional();
float avgNumCOVID_Cases_Conditional();
float numInfectedPeopleatBeginningInClassroom_RegionalRates();
float probabilityOfInfection_OneEvent_RegionalRates();
float numInfectedPeopleAfterEvent_RegionalRate();
float probabilityOfInfectionMultipleEvents_RegionalRates();
float numberOfCOVID_CasesOverTime_RegionalRate();
void  changeMaskWearingFraction();


int main()
{

	readInValues();
	createDirectOutput();
	changeMaskWearingFraction();

}

//For this assignment you can put all you global function implementations after main
//Later we will talk about multiple file implementations! 

void changeMaskWearingFraction()
{
	//place the data in a CSV format 
	//we will assume a regional rate here 

	ofstream outFile("mask_data.dat", ios::out);

	fractionPeopleWearingMasks = 0;

	while (fractionPeopleWearingMasks <= 1.0)
	{
		outFile << 100*fractionPeopleWearingMasks << "," << setprecision(5) << 
		100*probabilityOfInfectionMultipleEvents_RegionalRates() << endl;

		fractionPeopleWearingMasks += 0.01;
	}
}

void createDirectOutput()
{
	system("clear");

	string inputString;
	cout << "Please indicate output file name: " ;
	cin >> inputString;
	ofstream outFile(inputString.c_str(), ios::out);

	const int label_width = 85;
   	const int value_width = 15;
	//Volume of Room
	outFile <<left<< setw(label_width) << "The volume of your room [cubic meters]:" 
            << right << setw(value_width) << setprecision(5) << volOfRoom() << endl;
	//Viral Loss Rate
	outFile << left << setw(label_width) << "The total viral loss rate [per hour]:"
	    << right << setw(value_width) << setprecision(5) << totalFirstOrderViralLossRate() << endl;

	//Susceptible People
	outFile << left << setw(label_width) << "The number of people susceptible in the room:" << right << setw(value_width) << setprecision(5) << numPeopleSusceptible() << endl;
	//Area per person
	outFile << left << setw(label_width) << "The square-ft area per person [ft^2/person]:" << right << setw(value_width) << setprecision(5) << areaPerPersonInRoom() <<endl;
	//Persons per square meter
	outFile << left << setw(label_width) << "The persons per square meter [person/m^2]:" << right << setw(value_width) << setprecision(5) << personsPerSquareMeter() << endl;
        //Volume per person
	outFile << left << setw(label_width) << "The cubic meter volume per person is [m^3/person]:" << right << setw(value_width) << setprecision(5) << volumePerPerson() << endl;
        //Ventilation Rate
	outFile << left << setw(label_width) << "The ventilation rate per person in the room [L/s/person]:" << right << setw(value_width) << setprecision(5) << ventRatePerPerson() << endl;
	//Quanta Rate
	outFile << left << setw(label_width) << "The quanta exhalation rate from infected people [quanta/hr]:" << right << setw(value_width) << setprecision(5) << netEmissionRateFromInfected() << endl;
        //Quanta Concentration
	outFile << left << setw(label_width) << "The average viral quanta concentration in the room [quanta/L]:" << right << setw(value_width) << setprecision(5) << avgQuantaConcentration() << endl;
	//Quanta Inhaled
	outFile << left << setw(label_width) << "The average quanta inhaled per person in the room [quanta]:" << right << setw(value_width) << setprecision(5) << quantaInhaledPerPerson() << endl;
	//Conditional Case
	outFile<<" "<<endl;
	outFile<<"== CONDITIONAL CASE ===============================================================================" << endl;
	//Prob of Infection if 1
	outFile << left << setw(label_width) << "The probability of infection IF 1 infected person(s) in the room [%]:" << right << setw(value_width) << setprecision(5) << probabilityOfInfection_Conditional()*100 << endl;
	//Avg New cases
	outFile << left << setw(label_width) << "The average number of new COVID cases for conditional case:" << right << setw(value_width) << setprecision(5) << avgNumCOVID_Cases_Conditional() << endl;

	//Regional Case
	outFile << " " <<endl;
	outFile << "== REGIONAL CASE ONE EVENT ========================================================================" << endl;
	//Starting Number of Infected
	outFile << left << setw(label_width) << "Starting number of infected people based on regional infection rates in the room:" << right <<setw(value_width) << setprecision(5) << numInfectedPeopleatBeginningInClassroom_RegionalRates() << endl;
	//Prob of infection regional rates
	outFile << left << setw(label_width) << "The probability of being infected given the regional rates [%]:" << right << setw(value_width) << setprecision(5) << probabilityOfInfection_OneEvent_RegionalRates()*100 << endl;
	//Single Event Number of Infected
	outFile << left << setw(label_width) << "The average number of infected people after a single event:" << right << setw(value_width) << setprecision(5) << numInfectedPeopleAfterEvent_RegionalRate() << endl;

	//Regional Case Mult Events
	outFile << " " << endl;
	outFile << "== REGIONAL CASE MULTIPLE EVENTS ==================================================================" <<endl;
	//30 Events probability
	outFile << left << setw(label_width) << "The probability of being infected after going to 30 [%]:" << right << setw(value_width) <<setprecision(5) << probabilityOfInfectionMultipleEvents_RegionalRates()*100 << endl;
	//Num of People after 30 events
	outFile << left << setw(label_width) << "The number of people expected to get COVID after 30 events:" << right << setw(value_width) << setprecision(5) << numberOfCOVID_CasesOverTime_RegionalRate() << endl;

	//You must complete the rest of the output to match the output file exactly! 
	//This will help the TA's grade you code a little faster! 

}//end createDirectOutput
//Start Functions
float volOfRoom()
{
	return( lengthOfRoomft*widthOfRoomft*heightOfRoomft*convertCubicFtToCubicMeter);
}

float totalFirstOrderViralLossRate()
{
	return(ventilationWithOutsideAir+decayRateOfVirus+depositionToSurfaces+additionalControlMeasures);
}

float numPeopleSusceptible()
{
	return((numPeoplePresent-numInfectedPeopleInRoom)*(1-fractionOfPopulationImmune));
}
float ventRatePerPerson()
{
	float volume = volOfRoom();
	float num = .2777777778;
	float ventContr = ventilationWithOutsideAir + additionalControlMeasures;
	return((num* volume * ventContr)/numPeoplePresent);
}

float areaPerPersonInRoom() 
{
	return(lengthOfRoomft*widthOfRoomft/(numPeoplePresent));
}

float personsPerSquareMeter()
{
	return(numPeoplePresent/(lengthOfRoomft*widthOfRoomft*(pow(0.305,2))));
}
float volumePerPerson() 
{
	return(volOfRoom()/numPeoplePresent);
}

float netEmissionRateFromInfected()
{
	return(quantaExhalationRate_Infected*(1.0-(exhalationMaskEfficiency*fractionPeopleWearingMasks))*numInfectedPeopleInRoom);
}

float avgQuantaConcentration()
{
	float vloss = totalFirstOrderViralLossRate();
	float emiss = netEmissionRateFromInfected();
	return(emiss/(vloss*volOfRoom())*(1.0-(1.0/(vloss*durationOfEventInMins/60.0f))*(1.0 - exp(-vloss*durationOfEventInMins/60.0f))));
}

float quantaInhaledPerPerson()
{
	return(avgQuantaConcentration()*breathingRateSusceptiblePeople*(durationOfEventInMins/60.0f)*(1.0-(inhalationMaskEfficiency*fractionPeopleWearingMasks)));
}

float probabilityOfInfection_Conditional()
{
	return(1.0-exp(-quantaInhaledPerPerson()));
}

float avgNumCOVID_Cases_Conditional()
{
	return(numPeopleSusceptible()*probabilityOfInfection_Conditional());
}

float numInfectedPeopleatBeginningInClassroom_RegionalRates()
{
	return((numInfectedPeopleInRoom + numPeopleSusceptible())*infectionRateInYourArea);
}

float probabilityOfInfection_OneEvent_RegionalRates()
{
	float x = infectionRateInYourArea;
	float y =1.0-(probabilityOfInfection_Conditional()*x);
	float z = numPeopleSusceptible();
	float result = pow(y,z);
	return(1.0 - result);
}

float numInfectedPeopleAfterEvent_RegionalRate()
{
	return((numInfectedPeopleInRoom+numPeopleSusceptible())*probabilityOfInfection_OneEvent_RegionalRates());
}

float probabilityOfInfectionMultipleEvents_RegionalRates()
{
        float x =1.0- probabilityOfInfection_OneEvent_RegionalRates();
	float y =numRepsOfEvent;
	float result = pow(x,y); 
	return(1.0 - result);
}

float numberOfCOVID_CasesOverTime_RegionalRate()
{
	float probI = probabilityOfInfectionMultipleEvents_RegionalRates();
	float sus = numPeopleSusceptible();
	float classI = numInfectedPeopleatBeginningInClassroom_RegionalRates();
	return(probI*(sus-classI));
}
//End of Function


void readInValues()
{

	ifstream inputFile("parameters.txt", ios::in);

	if (!inputFile) //is not valid
	{	
		cerr << "The file parameters.txt does not seem to exist!" << endl;
	}  // the file is good now read in values
	else
	{
		string trash; //this will read in the markers in the file
	
		inputFile >> lengthOfRoomft >> trash ;
		inputFile >> widthOfRoomft >> trash;
		inputFile >> heightOfRoomft >> trash;
		inputFile >> durationOfEventInMins >> trash;
		inputFile >> numRepsOfEvent >> trash;
		inputFile >> ventilationWithOutsideAir >> trash;
		inputFile >> decayRateOfVirus >> trash;
		inputFile >> depositionToSurfaces >> trash;
		inputFile >> additionalControlMeasures >> trash;
		inputFile >> numPeoplePresent >> trash;
		inputFile >> numInfectedPeopleInRoom >> trash;
		inputFile >> fractionOfPopulationImmune >> trash;
		inputFile >> breathingRateSusceptiblePeople >> trash;
		inputFile >> quantaExhalationRate_Infected >> trash;
		inputFile >> exhalationMaskEfficiency >> trash;
		inputFile >> fractionPeopleWearingMasks >> trash;
		inputFile >> inhalationMaskEfficiency >> trash;
		inputFile >> infectionRateInYourArea >> trash;		
	}
	inputFile.close();
}

